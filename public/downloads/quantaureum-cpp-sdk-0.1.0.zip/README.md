# Quantaureum C++ SDK

现代 C++17 区块链 SDK，用于与 Quantaureum 网络交互。

## 特性

- 🔐 账户管理（私钥、助记词）
- 📝 交易签名和发送
- 📜 智能合约交互
- 🔧 ABI 编解码
- ⚡ 异步 API 支持
- 🧪 属性测试覆盖

## 要求

- C++17 兼容编译器
- CMake 3.16+
- libcurl
- OpenSSL

## 安装

### 使用 CMake FetchContent

```cmake
include(FetchContent)
FetchContent_Declare(
    quantaureum
    GIT_REPOSITORY https://github.com/quantaureum/cpp-sdk.git
    GIT_TAG v0.1.0
)
FetchContent_MakeAvailable(quantaureum)

target_link_libraries(your_target quantaureum)
```

### 手动构建

```bash
git clone https://github.com/quantaureum/cpp-sdk.git
cd cpp-sdk
mkdir build && cd build
cmake ..
cmake --build .
```

## 快速开始

```cpp
#include <quantaureum/quantaureum.hpp>
#include <iostream>

using namespace quantaureum;

int main() {
    // 地址操作
    Address addr = Address::fromHex("0x742d35Cc6634C0532925a3b844Bc9e7595f8fE00");
    std::cout << "Address: " << addr.toChecksumHex() << std::endl;
    
    // 单位转换
    Uint256 wei = Convert::etherToWei("1.5");
    std::cout << "1.5 ETH = " << wei.toHex() << " wei" << std::endl;
    
    // Keccak256 哈希
    Hash hash = Keccak256::hash("hello");
    std::cout << "Hash: " << hash.toHex() << std::endl;
    
    // 十六进制转换
    std::vector<uint8_t> data = {0x01, 0x02, 0x03};
    std::string hex = Hex::toHexString(data);
    std::cout << "Hex: " << hex << std::endl;
    
    return 0;
}
```

## API 参考

### Address

```cpp
// 创建地址
Address addr = Address::fromHex("0x...");
Address addr = Address::fromBytes(bytes);

// 转换
std::string hex = addr.toHex();
std::string checksum = addr.toChecksumHex();
auto bytes = addr.toBytes();

// 验证
bool valid = Address::isValid("0x...");
```

### Uint256

```cpp
// 创建
Uint256 value(12345);
Uint256 value = Uint256::fromHex("0x...");

// 算术运算
Uint256 sum = a + b;
Uint256 diff = a - b;
Uint256 prod = a * b;
Uint256 quot = a / b;

// 比较
bool less = a < b;
bool equal = a == b;
```

### Convert

```cpp
// Ether <-> Wei
Uint256 wei = Convert::etherToWei("1.5");
std::string ether = Convert::weiToEther(wei);

// Gwei <-> Wei
Uint256 wei = Convert::gweiToWei("20");
std::string gwei = Convert::weiToGwei(wei);

// 通用单位转换
Uint256 wei = Convert::toWei("1", Unit::Ether);
std::string value = Convert::fromWei(wei, Unit::Gwei);
```

### Keccak256

```cpp
// 哈希字符串
Hash hash = Keccak256::hash("hello");

// 哈希字节
std::vector<uint8_t> data = {...};
Hash hash = Keccak256::hash(data);

// 直接获取十六进制
std::string hex = Keccak256::hashToHex("hello");
```

### Hex

```cpp
// 字节转十六进制
std::string hex = Hex::toHexString(bytes);

// 十六进制转字节
std::vector<uint8_t> bytes = Hex::toBytes("0xabcd");

// 前缀操作
bool hasPrefix = Hex::has0xPrefix("0xabc");
std::string with = Hex::add0xPrefix("abc");
std::string without = Hex::remove0xPrefix("0xabc");
```

## 测试

```bash
cd build
ctest --output-on-failure
```

## 许可证

MIT License
